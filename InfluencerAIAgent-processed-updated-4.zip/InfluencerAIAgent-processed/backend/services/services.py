
def process_user_data(user):
    # Logic to process user data
    processed_data = {'processed_name': user.name.upper()}
    return processed_data
